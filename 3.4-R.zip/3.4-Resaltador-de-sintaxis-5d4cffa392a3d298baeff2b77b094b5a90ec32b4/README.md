# 3.4-Resaltador-de-sintaxis
### Javascript
## Operadores


## Operadores de Comparacion 

## Comentarios 
// Single Line 

/* Mult Line */


## Variables
let x

var x

const x

(undeclared) x


## Funciones
function myFunction(){} 

myFunction() =>{}

## Strings
“hola”

## Números
1

## Identificadores
let NombreDeVariable = “hola”

let NombreArreglo = [ x, y, z]

let NombreDeContador = 0   


## Constantes literales
let NombreContador = 0

let NombreBoolen = true

let NombreString = “myString”


## Delimitadores
If (comparador) {}

for (contador) {}

## Palabras Reservadas
float

double 

boolean

return

in
